import java.util.Stack;

public class Pila {

    private Stack<String> arreglo;

    public Pila() {
        this.arreglo = new  Stack<String>();
    }

    public void apilar(String dato) throws Exception{
        if (arreglo.size()<10){
            arreglo.push(dato);
        } else{
            throw new Exception("Limite alcanzado");
        }


    }

    public String desapilar() throws Exception {
        if (arreglo.isEmpty()){
            throw new Exception("Error al desapilar la pila");
        } else {
            return arreglo.pop();
        }

    }

    public String cima() throws Exception{

        if (arreglo.isEmpty()){
            throw new Exception("Error al mostrar el ultimo dato");
        } else {
            return arreglo.peek();
        }
    }

    @Override
    public String toString() {
        StringBuilder cadena = new StringBuilder();
        for(int indice = arreglo.size() - 1; indice >= 0; indice--){
            cadena.append(arreglo.get(indice)).append("\n");
        }
        return cadena.toString();
    }
}
