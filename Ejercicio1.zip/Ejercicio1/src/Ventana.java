import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextField txtApilar;
    private JButton btnApilar;
    private JButton btnDesapilar;
    private JTextArea txtaMostrar;
    private JLabel lblApilar;
    private JButton btnCima;
    private Pila lista = new Pila();

    public Ventana() {

        btnApilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    lista.apilar(txtApilar.getText());
                    txtApilar.setText("");
                    txtaMostrar.setText(lista.toString());
                } catch (Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        btnDesapilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String eliminado  ;
                try {
                    eliminado = lista.desapilar();
                    JOptionPane.showMessageDialog(null,"Eliminado: "+ eliminado);
                    txtaMostrar.setText(lista.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }



            }
        });
        btnCima.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cima  ;
                try {
                    cima = lista.cima();
                    JOptionPane.showMessageDialog(null,"Ultimo dato: "+ cima);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


}
