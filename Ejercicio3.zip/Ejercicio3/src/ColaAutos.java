import java.util.ArrayDeque;
import java.util.Queue;

public class ColaAutos {
    private final int actual = 2025;
    Queue<Auto> autos;


    public int getActual() {
        return actual;
    }

    public ColaAutos(){
        autos = new ArrayDeque<>();
    }

    public void encolar(Auto dato){
        autos.add(dato);
    }

    public Auto desencolar() throws Exception{
        if(autos.isEmpty()){
            throw new Exception("No hay autos encolados");
        }
        return autos.poll();
    }

    public int pago(int anioSeleccionado){
        int diferencia = actual - anioSeleccionado;
        return diferencia * 50;
    }

    public String listarTodos(){
        StringBuilder sb = new StringBuilder();
        for(Auto autoX:autos){
            sb.append(autoX.toString());
        }
        return sb.toString();
    }
}
